<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    // header('content-encoding:'deflate', 'br');
    // if(ini_get('zlib.output_compression')){ 
    //     ini_set('zlib.output_compression', 'Off'); 
    // }

?>