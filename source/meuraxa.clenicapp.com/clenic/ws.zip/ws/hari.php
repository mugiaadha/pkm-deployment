<?php
/*if ($namahari == "Sunday") $namahari = "Minggu";
else if ($namahari == "Monday") $namahari = "Senin";
else if ($namahari == "Tuesday") $namahari = "Selasa";
else if ($namahari == "Wednesday") $namahari = "Rabu";
else if ($namahari == "Thursday") $namahari = "Kamis";
else if ($namahari == "Friday") $namahari = "Jumat";
else if ($namahari == "Saturday") $namahari = "Sabtu";
*/
if ($namahari == "Sunday") $namahari = "FMJHari07";
else if ($namahari == "Monday") $namahari = "FMJHari01";
else if ($namahari == "Tuesday") $namahari = "FMJHari02";
else if ($namahari == "Wednesday") $namahari = "FMJHari03";
else if ($namahari == "Thursday") $namahari = "FMJHari04";
else if ($namahari == "Friday") $namahari = "FMJHari05";
else if ($namahari == "Saturday") $namahari = "FMJHari06";
?>